<?php
$po_lang = array(
	'yil' => 'Year',
	'ay' => 'Month',
	'gun' => 'Day',
	'saat' => 'Hour',
	'dakika' => 'Minute',
	'kampanya-sona-erdi' => 'Campaign Ended'
);
$lang_array = array_merge($lang_array,$po_lang);