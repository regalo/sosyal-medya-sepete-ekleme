<?php
$po_lang = array(
	'yil' => 'Yıl',
	'ay' => 'Ay',
	'gun' => 'Gün',
	'saat' => 'Saat',
	'dakika' => 'Dakika',
	'kampanya-sona-erdi' => 'Kampanya Sona Erdi'
);
$lang_array = array_merge($lang_array,$po_lang);