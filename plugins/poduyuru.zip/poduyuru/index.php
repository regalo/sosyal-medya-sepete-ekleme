<?php
$name = "Popup Duyuru Eklentisi";
$primary = "poduyuru";
$demo = "https://nivusoft.com/plugin/poduyuru/";
$screenshot = ns_filter('siteurl').'plugins/poduyuru/screenshot.png';
$version = 1.5;
$autor = "nivusoft";
$description = "Nivusosyal yazılımı için geliştirilmiş Popup duyuru eklentisi";
require "function.php";